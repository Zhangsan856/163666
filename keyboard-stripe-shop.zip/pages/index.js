import { loadStripe } from '@stripe/stripe-js';

const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLIC_KEY);

export default function Home() {
  const handleCheckout = async () => {
    const stripe = await stripePromise;
    const res = await fetch('/api/checkout', { method: 'POST' });
    const data = await res.json();
    stripe.redirectToCheckout({ sessionId: data.id });
  };

  return (
    <div style={{ padding: 50, textAlign: 'center' }}>
      <h1>机械键盘 - $50</h1>
      <img src="https://via.placeholder.com/400x200.png?text=Mechanical+Keyboard" />
      <br /><br />
      <button onClick={handleCheckout}>立即购买</button>
    </div>
  );
}
